package com.example.ec03
import retrofit2.Call
import retrofit2.http.GET

interface ChuckNorrisService {
    @GET("jokes/random/10")
    fun getJokes(): Call<List<ChuckNorrisJoke>>
}

