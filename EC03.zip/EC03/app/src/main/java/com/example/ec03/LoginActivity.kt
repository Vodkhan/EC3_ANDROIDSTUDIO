package com.example.ec03

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import com.example.ec03.databinding.ActivityLoginBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import android.content.Intent

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.etEmail.addTextChangedListener(textWatcher)
        binding.etPassword.addTextChangedListener(textWatcher)


        binding.btnLogin.setOnClickListener {

            val email = binding.etEmail.text.toString()
            val password = binding.etPassword.text.toString()


            if (email == "ejemplo@idat.edu.pe" && password == "123456") {

            } else {

        }


        binding.btnLogin.isEnabled = false


        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.action_list -> {
                    // Handle List option click
                    true
                }
                R.id.action_favorite -> {
                    // Handle Favorite option click
                    true
                }
                R.id.action_info -> {
                    // Handle Info option click
                    true
                }
                else -> false
            }
        }
    }

    private val textWatcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

        override fun afterTextChanged(s: Editable?) {
            val email = binding.etEmail.text.toString()
            val password = binding.etPassword.text.toString()
            binding.btnLogin.isEnabled = email.isNotBlank() && password.isNotBlank()
        }
    }
    private fun navigateToJokesActivity() {
        val intent = Intent(this, JokesActivity::class.java)
        startActivity(intent)
        finish()
    }
}


