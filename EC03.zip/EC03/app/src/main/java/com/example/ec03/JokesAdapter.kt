package com.example.ec03

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.ec03.databinding.ItemJokeBinding

class JokesAdapter : ListAdapter<ChuckNorrisJoke, JokesAdapter.JokesViewHolder>(JokesDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JokesViewHolder {
        val binding = ItemJokeBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return JokesViewHolder(binding)
    }

    override fun onBindViewHolder(holder: JokesViewHolder, position: Int) {
        val joke = getItem(position)
        holder.bind(joke)
    }

    class JokesViewHolder(private val binding: ItemJokeBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(joke: ChuckNorrisJoke) {
            binding.joke = joke
            binding.executePendingBindings()
        }
    }

    class JokesDiffCallback : DiffUtil.ItemCallback<ChuckNorrisJoke>() {
        override fun areItemsTheSame(oldItem: ChuckNorrisJoke, newItem: ChuckNorrisJoke): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: ChuckNorrisJoke, newItem: ChuckNorrisJoke): Boolean {
            return oldItem == newItem
        }
    }
}
