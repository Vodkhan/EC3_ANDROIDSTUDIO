package com.example.ec03

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ec03.databinding.ActivityJokesBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit

class JokesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityJokesBinding
    private lateinit var jokesAdapter: JokesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityJokesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        jokesAdapter = JokesAdapter()

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@JokesActivity)
            adapter = jokesAdapter
        }

        getJokes()
    }

    private fun getJokes() {
        val chuckNorrisService = RetrofitClient.chuckNorrisService
        val call = chuckNorrisService.getJokes()
        call.enqueue(object : Callback<List<ChuckNorrisJoke>> {
            override fun onResponse(call: Call<List<ChuckNorrisJoke>>, response: Response<List<ChuckNorrisJoke>>) {
                if (response.isSuccessful) {
                    val chuckNorrisJokesList: List<ChuckNorrisJoke>? = response.body()
                    val jokesList: List<Joke> = chuckNorrisJokesList?.map { chuckNorrisJoke ->
                        Joke(chuckNorrisJoke.id, chuckNorrisJoke.value)
                    } ?: emptyList()

                    jokesAdapter.submitList(jokesList)
                }
            }

            override fun onFailure(call: Call<List<ChuckNorrisJoke>>, t: Throwable) {

            }
        })
    }
}