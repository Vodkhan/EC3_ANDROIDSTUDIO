package com.example.ec03

data class ChuckNorrisJoke(
    val id: String,
    val value: String
)