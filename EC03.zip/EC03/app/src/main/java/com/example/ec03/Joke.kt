package com.example.ec03

data class Joke(val id: String, val text: String)